# Green Button Patch (🟢)
Detta lägger till en privat, token-skyddad knapp som skickar ett test-SMS via er redan körande server.

## 1) Lägg till i .env
Lägg till en hemlig token (byt ut exemplet):
```
GREEN_TOKEN=byt_till_en_lång_slumpsträng
```

## 2) Patcha server.js (lägg dessa rader nära dina andra routes)
```js
const GREEN_TOKEN = process.env.GREEN_TOKEN;

app.post('/green-send', async (req, res) => {
  try {
    const token = req.query.token || (req.body && req.body.token);
    if (!token || token !== GREEN_TOKEN) {
      return res.status(401).json({ ok:false, error:'unauthorized' });
    }
    const r = await smsNotify('📨 Letters test — Du är live nu!');
    if (r.ok) return res.json({ ok:true, sid:r.sid });
    return res.status(400).json(r);
  } catch (e) {
    return res.status(500).json({ ok:false, error:e.message });
  }
});
```

## 3) Lägg in green.html
Kopiera `public/green.html` till projektets `public/`-mapp (den servas redan med `express.static`).

## 4) Starta om servern
`npm start` (eller starta om processen i Render/Replit).

## 5) Använd knappen
Öppna på mobilen (byt DOMÄN och TOKEN):
```
https://DIN-SERVER/green.html?token=DIN_HEMLIGA_TOKEN
```
Tryck **🟢 Skicka test** → du får SMS. Ingen ser sidan utan korrekt token.
