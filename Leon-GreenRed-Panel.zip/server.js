// server.js (Green/Red Panel)
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Mongo ---
let mongoStatus = { connected: false, error: null };
mongoose.connect(process.env.MONGO_URI)
  .then(() => { mongoStatus.connected = true; console.log("✅ Mongo connected"); })
  .catch(err => { mongoStatus.connected = false; mongoStatus.error = err.message; console.error("❌ Mongo error:", err.message); });

// --- Twilio (safe) ---
let twilioClient = null;
let twilioStatus = { enabled: false, reason: "not_configured" };
(() => {
  const sid   = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from  = process.env.TWILIO_PHONE_NUMBER;
  const owner = process.env.TWILIO_OWNER_NUMBER;
  if (!sid || !token || !from) { console.log("ℹ️ Twilio disabled (missing env vars)."); return; }
  try { twilioClient = require('twilio')(sid, token); twilioStatus = { enabled: true, from, owner: owner || null }; console.log("✅ Twilio ready"); }
  catch (e) { twilioClient = null; twilioStatus = { enabled: false, reason: e.message || "init_error" }; console.log("⚠️ Twilio init error:", twilioStatus.reason); }
})();

// --- Health & config check ---
app.get('/health', (_req, res) => {
  res.json({ ok: true, mongo: mongoStatus.connected, twilio: twilioStatus });
});

// checks for placeholders like <DITT_LÖSEN> still present
function hasPlaceholder(v){ if (!v) return true; return /<.*>/.test(v); }

app.get('/config-check', (_req, res) => {
  const env = process.env;
  const report = {
    mongo_uri_present: !!env.MONGO_URI,
    mongo_uri_has_placeholder: hasPlaceholder(env.MONGO_URI),
    twilio_sid_present: !!env.TWILIO_ACCOUNT_SID,
    twilio_token_present: !!env.TWILIO_AUTH_TOKEN,
    twilio_from_present: !!env.TWILIO_PHONE_NUMBER,
    twilio_owner_present: !!env.TWILIO_OWNER_NUMBER,
    mongo_connected: mongoStatus.connected,
    twilio_enabled: twilioStatus.enabled,
  };
  const ok = report.mongo_uri_present && !report.mongo_uri_has_placeholder && report.mongo_connected !== false;
  res.json({ ok, report });
});

// test SMS without typing "to": uses owner as default
app.post('/send-sms', async (req, res) => {
  if (!twilioClient || !twilioStatus.enabled) return res.status(503).json({ ok:false, error:"Twilio not configured" });
  const to = (req.body?.to || process.env.TWILIO_OWNER_NUMBER || "").toString();
  const body = (req.body?.text || "Hej från Leon 🗝️").toString();
  if (!to) return res.status(400).json({ ok:false, error:"Missing TWILIO_OWNER_NUMBER" });
  try {
    const msg = await twilioClient.messages.create({ body, from: process.env.TWILIO_PHONE_NUMBER, to });
    res.json({ ok:true, sid: msg.sid });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

app.get('/', (_req, res) => res.redirect('/panel.html'));

app.listen(PORT, () => console.log(`🔥 Server running on port ${PORT}`));
