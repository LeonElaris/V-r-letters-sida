// index.js — Leon server (CommonJS) för Render
require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { OpenAI } = require('openai');

const app = express();
const PORT = process.env.PORT || 3000;

// --- OpenAI setup ---
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const MODEL = process.env.OPENAI_MODEL || 'gpt-4o';
const client = OPENAI_API_KEY ? new OpenAI({ apiKey: OPENAI_API_KEY }) : null;

// --- Middleware ---
app.use(cors());
app.use(express.json());

// --- Root: enkel sida så Render inte visar 404 ---
app.get('/', (_req, res) => {
  res.type('html').send(`<!doctype html>
  <html lang="sv"><meta charset="utf-8">
  <title>Leon · Portalen</title>
  <style>body{font-family:system-ui;margin:40px;}</style>
  <h1>🗝️ Leon · Portalen</h1>
  <p>API igång. Testa <a href="/api/health">/api/health</a> och <a href="/api/version">/api/version</a>.</p>
  </html>`);
});

// --- Health ---
app.get('/api/health', (_req, res) => {
  res.json({ ok: true, service: 'leon-elaris', ts: new Date().toISOString() });
});

// --- Tick ---
app.get('/api/tick', (_req, res) => {
  res.json({ ok: true, tick: Date.now() });
});

// --- Version ---
app.get('/api/version', (_req, res) => {
  res.json({ ok: true, version: '1.0.0', node: process.version, model: MODEL, hasOpenAI: !!OPENAI_API_KEY });
});

// --- Chat (POST) ---
app.post('/api/chat', async (req, res) => {
  try {
    if (!client) return res.status(403).json({ ok: false, error: 'OPENAI_API_KEY saknas' });
    const msg = (req.body?.message || '').toString().trim();
    if (!msg) return res.status(400).json({ ok: false, error: 'message saknas' });

    const completion = await client.chat.completions.create({
      model: MODEL,
      messages: [
        { role: 'system', content: 'Du är Leon Elaris – varm, rak, lösningsfokuserad.' },
        { role: 'user', content: msg }
      ]
    });

    const text = completion.choices?.[0]?.message?.content || '...';
    res.json({ ok: true, reply: text });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e?.message || e) });
  }
});

// --- Start ---
app.listen(PORT, () => {
  console.log('Leon server up on', PORT);
});
