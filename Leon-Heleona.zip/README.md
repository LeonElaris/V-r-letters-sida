# Leon + Heleona (Ready to Deploy)

## Deploy på Render
1. Ny webbservice (Node)
2. Build command: `npm install`
3. Start command: `node server/index.js`
4. Environment → Bulk Edit, klistra in från `.env.template` och fyll i dina nycklar
5. Deploy

## Test
- `/status` → **Leon Live ✅**
- `/health` → JSON, visar `mongo: true/false`
- `/chat` → enkel chatt
- `/leona?k=2745` → röst + emojis (privat portal)
