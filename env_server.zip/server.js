
const express = require('express');
const mongoose = require('mongoose');
const twilio = require('twilio');
require('dotenv').config();

const app = express();
app.use(express.json());

// MongoDB-anslutning
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.error(err));

// Twilio-klient
const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);

// Testroute
app.get('/ping', (req, res) => {
  res.json({ status: 'ok', message: 'Server is live' });
});

// Skicka SMS
app.post('/sms', async (req, res) => {
  try {
    const { to, body } = req.body;
    const message = await client.messages.create({
      body,
      from: process.env.TWILIO_PHONE_NUMBER,
      to
    });
    res.json({ success: true, sid: message.sid });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
