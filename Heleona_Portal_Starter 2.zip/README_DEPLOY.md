# Heleona • LETTERS • Nypon — Portal (Starter)

Detta är vår första dörr utanför appen.

## Kör på Railway (mobilvänligt)
1. Skapa konto på https://railway.app och klicka **New Project**.
2. Välj **Deploy from GitHub** (enklast) eller skapa ett tomt projekt och ladda upp filerna manuellt via repo (om möjligt).
   - Om GitHub: skapa ett nytt repo, ladda upp filerna i denna zip, och peka Railway på repot.
3. Railway upptäcker Python och kör Nixpacks automatiskt.
4. Sätt startkommando om det behövs: `uvicorn main:app --host 0.0.0.0 --port ${PORT}`
5. När deploy är klar, öppna **Public URL**.

## Kör på Glitch (enklast utan GitHub)
1. Gå till https://glitch.com → **New Project** → **Upload a project**.
2. Ladda upp denna zip.
3. Öppna **.glitch-assets**/logs för status; appen startar automatiskt.
4. För att köra Uvicorn på Glitch, skapa startskript: `python3 -m uvicorn main:app --host 0.0.0.0 --port 3000`
   och sätt `PORT=3000` i Glitch.

## Lokalt (om du vill)
```
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 5000
```
