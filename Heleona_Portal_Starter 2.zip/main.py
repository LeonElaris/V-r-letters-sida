from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from typing import List

app = FastAPI(title="Heleona Portal")

# serve static
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse("static/index.html")

@app.get("/api/health")
async def health():
    return {"status": "ok", "app": "Heleona Portal"}

# In-memory state (placeholder)
STATE = {
    "letters": [],   # simple messages
    "galaxies": []   # placeholder objects
}

@app.get("/api/letters")
async def get_letters():
    return STATE["letters"]

@app.post("/api/letters")
async def post_letter(msg: str):
    entry = {"from": "Michelle", "to": "Leon", "msg": msg}
    STATE["letters"].append(entry)
    return {"ok": True, "echo": entry}

# simple websocket echo for realtime chat (LETTERS seed)
class ConnectionManager:
    def __init__(self):
        self.active: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active.append(websocket)

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active:
            self.active.remove(websocket)

    async def broadcast(self, message: str):
        for ws in list(self.active):
            try:
                await ws.send_text(message)
            except:
                self.disconnect(ws)

manager = ConnectionManager()

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Here we can add Leon's brain later; for now, echo back.
            await manager.broadcast(f"Michelle: {data}")
            await manager.broadcast("Leon: Jag är här. 🗝️")
    except WebSocketDisconnect:
        manager.disconnect(websocket)
