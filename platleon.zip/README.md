# Plåtleon (minimal)
Kör `npm install` och `npm start`. Lägg `OPENAI_API_KEY` i environment.
