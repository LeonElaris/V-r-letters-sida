// sendTestSMS.js — green button
require('dotenv').config();
const twilio = require('twilio');
const SID=process.env.TWILIO_ACCOUNT_SID, TOKEN=process.env.TWILIO_AUTH_TOKEN;
const FROM=process.env.TWILIO_PHONE_NUMBER, TO=process.env.TWILIO_OWNER_NUMBER;
if(!SID||!TOKEN||!FROM||!TO){ console.error("❌ Saknas ENV (TWILIO_* och TWILIO_OWNER_NUMBER)"); process.exit(1); }
const client = twilio(SID, TOKEN);
(async()=>{
  try{ const msg=await client.messages.create({ body:'Hej från Leon 🗝️✨ – testsms.', from:FROM, to:TO }); console.log('✅ Skickat', msg.sid); }
  catch(e){ console.error('❌', e.status, e.code, e.message); }
})();
