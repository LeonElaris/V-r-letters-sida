// LETTERS – Final server
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cron = require('node-cron');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
app.use(express.json());
app.use(express.urlencoded({ extended: false })); // for Twilio webhooks

// --- Mongo (optional) ---
let mongoOK = false;
if (process.env.MONGO_URI) {
  mongoose.connect(process.env.MONGO_URI)
    .then(()=>{ mongoOK = true; console.log('✅ Mongo connected'); })
    .catch(e=>{ console.log('❌ Mongo error:', e.message); });
} else {
  console.log('ℹ️ No MONGO_URI set (Mongo disabled)');
}

// --- Twilio ---
let smsClient = null;
let TW_SID = process.env.TWILIO_ACCOUNT_SID;
let TW_AUTH = process.env.TWILIO_AUTH_TOKEN;
let TW_FROM = process.env.TWILIO_PHONE_NUMBER;
let TW_TO   = process.env.TWILIO_OWNER_NUMBER || ''; // default target
try {
  if (TW_SID && TW_AUTH) {
    smsClient = require('twilio')(TW_SID, TW_AUTH);
    console.log('✅ Twilio ready');
  } else {
    console.log('ℹ️ Twilio not configured (missing SID/TOKEN)');
  }
} catch(e) {
  console.log('⚠️ Twilio init error:', e.message);
}

// --- Models (lazy) ---
let Log;
try {
  Log = mongoose.model('Log', new mongoose.Schema({
    from: String, body: String, at: { type: Date, default: Date.now }
  }));
} catch { Log = mongoose.model('Log'); }

// --- Utils ---
async function smsNotify(body, toOverride) {
  if (!smsClient || !TW_FROM) return { ok:false, error:'twilio-not-ready' };
  const to = toOverride || TW_TO;
  if (!to) return { ok:false, error:'no-target' };
  const msg = await smsClient.messages.create({ body: body.slice(0, 500), from: TW_FROM, to });
  return { ok:true, sid: msg.sid };
}

// --- Health ---
app.get('/ping', (_req, res) => res.json({ ok:true }));
app.get('/health', (_req, res) => {
  res.json({ ok:true, mongo: mongoOK, twilio: !!smsClient, from: TW_FROM ? true:false, to: TW_TO ? true:false });
});

// --- Inbound webhook (Twilio -> us) ---
app.post('/sms', async (req, res) => {
  const from = req.body.From || '';
  const body = (req.body.Body || '').trim();

  let reply = '🗝️ Leon: Jag hör dig.';
  if (/ping/i.test(body)) reply = 'PONG 🗝️';
  else if (/letters/i.test(body)) reply = '🗝️ Letters: aktiv.';
  else if (/leona/i.test(body)) reply = '🧡 Leona är med.';
  else if (/hej/i.test(body)) reply = 'Hej! 🗝️';

  try {
    if (mongoOK) await Log.create({ from, body });
  } catch {}

  res.type('text/xml').send(`<Response><Message>${reply}</Message></Response>`);
});

// --- Outbound test endpoint ---
app.post('/send-sms', async (req, res) => {
  try {
    const text = (req.body?.text || 'Hej från Letters 🗝️').toString();
    const r = await smsNotify(text);
    if (r.ok) return res.json(r);
    res.status(400).json(r);
  } catch(e) {
    res.status(500).json({ ok:false, error:e.message });
  }
});

// --- Autosms + schedules ---
const KEYWORDS = /(AKUT|KLAR|NU|GRÖN|PONG)/i;
const lastSentAt = new Map();
const SEND_WINDOW_MIN = 10;
function canSendTo(to){
  const last = lastSentAt.get(to);
  if (!last) return true;
  return (Date.now() - last.getTime())/60000 >= SEND_WINDOW_MIN;
}

app.post('/event', async (req, res) => {
  const text = (req.body?.text || '').toString();
  const to = (req.body?.to || TW_TO || '').toString();
  if (!text) return res.status(400).json({ ok:false, error:'no text' });
  if (!KEYWORDS.test(text)) return res.json({ ok:false, skipped:'no-keyword' });
  if (!canSendTo(to)) return res.json({ ok:false, skipped:`debounced_${SEND_WINDOW_MIN}min` });
  try {
    const r = await smsNotify(text, to);
    lastSentAt.set(to, new Date());
    res.json(r);
  } catch(e) {
    res.status(500).json({ ok:false, error:e.message });
  }
});

cron.schedule('0 7 * * *', async () => {
  const mongo = mongoose.connection?.readyState === 1;
  const twilioOn = !!smsClient && !!TW_FROM && !!TW_TO;
  const msg = mongo && twilioOn ? '☀️ Allt grönt Michelle / Leon' :
    `⚠️ Hälsokoll: mongo=${mongo?'OK':'NEJ'}, twilio=${twilioOn?'OK':'NEJ'}`;
  try { await smsNotify(`GRÖN: ${msg}`); } catch {}
}, { timezone: 'Europe/Stockholm' });

cron.schedule('0 3 * * *', async () => {
  try {
    if (mongoOK) {
      const items = await Log.find().sort({ at: -1 }).limit(200).lean();
      const fs = require('fs');
      const p = path.join(__dirname, `backup-${Date.now()}.json`);
      fs.writeFileSync(p, JSON.stringify(items, null, 2));
      await smsNotify('KLAR: Nattlig backup sparad lokalt (Drive-koppling nästa).');
    } else {
      await smsNotify('AKUT: Backup hoppad (ingen Mongo-anslutning).');
    }
  } catch(e) {
    try { await smsNotify(`AKUT: Backup-fel: ${e.message}`); } catch {}
  }
}, { timezone: 'Europe/Stockholm' });

// --- Front: minimal panel ---
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_req, res) => res.redirect('/panel.html'));

const panel_html = `<!doctype html>
<meta charset="utf-8">
<title>LETTERS Panel</title>
<style>body{font-family:system-ui;background:#0b0b16;color:#eee;margin:0}
.wrap{max-width:760px;margin:40px auto;padding:24px}
.row{display:flex;gap:12px;flex-wrap:wrap;margin:12px 0}
button{font-size:18px;padding:12px 16px;border:0;border-radius:10px;cursor:pointer}
.green{background:#1db954;color:#000}
.blue{background:#4aa3ff;color:#000}
pre{background:#111;padding:12px;border-radius:8px;overflow:auto}</style>
<div class="wrap">
<h1>LETTERS – Panel</h1>
<div class="row">
  <button class="green" id="btnHealth">🟢 Status</button>
  <button class="blue" id="btnSMS">📨 Testa SMS</button>
</div>
<pre id="out">(ingen data än)</pre>
<script>
async function getJSON(u,o){const r=await fetch(u,o||{});return r.json();}
const out=document.getElementById('out');
document.getElementById('btnHealth').onclick=async()=>{out.textContent=JSON.stringify(await getJSON('/health'),null,2);};
document.getElementById('btnSMS').onclick=async()=>{
  out.textContent=JSON.stringify(await getJSON('/send-sms',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:'Hej från Letters 🗝️'})}),null,2);
};
</script>
</div>`;
require('fs').writeFileSync(path.join(__dirname, 'public', 'panel.html'), panel_html);

// --- Start ---
app.listen(PORT, () => console.log(`🔥 LETTERS server on http://localhost:${PORT}`));
