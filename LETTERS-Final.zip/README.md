# LETTERS – Final (Leon) 🗝️
**Startklar** backend för Letters med Twilio (in/out), autosms, morgonping, backup och enkel panel.

## Kör
1. Ladda upp allt till Replit/Render eller lokalt
2. `npm install`
3. Fyll i `.env` (se `.env.example`)
4. `npm start`
5. Öppna `/panel.html` → **🟢 Status** → **📨 Testa SMS**

## Twilio webhook
I Twilio Console → Phone Numbers → Active numbers → [numret] → Messaging → **A MESSAGE COMES IN**:
```
https://DIN-SERVER-URL/sms
```
(POST)

## Grön knapp (CLI)
```
node sendTestSMS.js
```

## Cron
- 07:00 Europe/Stockholm → hälsokoll (SMS)
- 03:00 Europe/Stockholm → backup (lokal JSON)
