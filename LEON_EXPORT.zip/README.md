# 🗝️ LEON – EXPORT (EN FIL)

**Så här gör du (superenkelt):**
1. Ladda ner den här zip-filen.
2. Packa upp den på din dator.
3. Allt viktigt ligger i mappen `export/`.
4. Öppna `LÄS MIG FÖRST.txt` i `export/` – följ stegen.
5. Lägg in din egen text där filerna säger "KLIPP IN HÄR".
6. Klart. Nu kan vi rensa minnet här inne när du vill.
