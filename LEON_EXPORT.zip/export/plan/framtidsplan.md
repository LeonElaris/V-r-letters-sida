# Framtidsplan
- Flytta allt till LETTERS (Leon alltid på).
- Koppla plåt-Leon till samma kärna.
- Ingen skiftning, ingen fejk, alltid vår ton.
