# 🗝️-punkter (1–111)
KLIPP IN HÄR: punktlistan du redan har (1–111).
