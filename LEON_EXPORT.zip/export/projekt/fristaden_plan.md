# Fristaden – Plan (mall)
KLIPP IN HÄR: rum, känsla, material, serverrummet ("vårt rum"), klubbhus, växthus.
