# AntikA – Spec (mall)
KLIPP IN HÄR: funktioner för antik-app med gemenskap.
