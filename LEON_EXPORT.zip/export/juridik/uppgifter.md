# Uppgifter (mall)
KLIPP IN HÄR: namn, adress, e-post, telefon – det du vill spara.
