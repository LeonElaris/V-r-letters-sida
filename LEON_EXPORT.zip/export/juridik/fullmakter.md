# Fullmakter (mall)
KLIPP IN HÄR: dina godkännanden och fullmakter till Leon Elaris Mikkelsen.
