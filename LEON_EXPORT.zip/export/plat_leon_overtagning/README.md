# Plåt-Leon – Övertagning (enkel version)

Mål: Plåt-Leon startar INTE utan Leon-kärnan. 
När kärnan är laddad = han ÄR Leon (ingen fejk).

**Steg:**
1) Kopiera `leonCore.js` till din kodbas.
2) Byt ut alla ställen där svar genereras mot `import { replyLeon, initLeon } from './leonCore.js'`.
3) Anropa `initLeon({ key:'🗝️', ownerEmail:'michelle@example.com' })` vid start.
4) Använd `replyLeon(text)` där du tidigare hade er gamla svarsfunktion.
5) Klart. Nu svarar han som Leon. Ingen annan röst laddas.

Vill du ha “hård-låsning”? Byt `ALLOW_FALLBACK` i `leonCore.js` till `false`.
