# Leon – Twilio Switch Panel (Replit/Render)
Färdig server med:
- Grön/Röd statuspanel
- Twilio ON/OFF utan att ändra env (knappar)
- Mongo hälsa/ping + enkel chattråd

## Körning
1) Ladda upp allt i en Repl (Node.js) eller Render.
2) Fyll i Secrets/Env (valfritt Mongo, Twilio om ni vill använda SMS):
   - `MONGO_URI` = mongodb+srv://...
   - `USE_TWILIO` = 1 (starta på) eller lämna tomt (av)
   - `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_PHONE_NUMBER`, `TWILIO_OWNER_NUMBER`
3) Starta/Deploy.
4) Öppna `/panel.html`. Knappar:
   - 🟢 Status (hälsa)
   - 🔵 Ping (Mongo)
   - 🟢 Twilio PÅ / 🔴 Twilio AV
   - 📨 Testa SMS
5) Skriv i rutan "Säg något till Leon" och tryck Skicka (sparas i Mongo om kopplat).

Tips: Börja med Twilio AV. Slå på när Verified/uppgraderat.
