// server.js — Green/Red + Twilio Switch
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// --- Twilio switch (ENV default) ---
let useTwilio = process.env.USE_TWILIO === "1"; // 1 = ON, else OFF

// --- Mongo ---
let mongoStatus = { connected: false, error: null };
if (process.env.MONGO_URI) {
  mongoose.connect(process.env.MONGO_URI)
    .then(() => { mongoStatus.connected = true; console.log("✅ Mongo connected"); })
    .catch(err => { mongoStatus.connected = false; mongoStatus.error = err.message; console.error("❌ Mongo error:", err.message); });
} else {
  console.log("ℹ️ No MONGO_URI set (Mongo disabled)");
}

// --- Simple schema for chat memory (optional) ---
let Message;
try {
  Message = mongoose.model('Message', new mongoose.Schema({
    role: String,
    content: String,
    at: { type: Date, default: Date.now }
  }));
} catch(e) {
  Message = mongoose.model('Message');
}

// --- Twilio (safe init) ---
let twilioClient = null;
let twilioStatus = { enabled: false, reason: "not_configured", switch: useTwilio };
(function initTwilio(){
  if (!useTwilio) { console.log("ℹ️ Twilio disabled by switch."); return; }
  const sid   = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from  = process.env.TWILIO_PHONE_NUMBER;
  const owner = process.env.TWILIO_OWNER_NUMBER;
  if (!sid || !token || !from) { console.log("ℹ️ Twilio disabled (missing env vars)."); return; }
  try { twilioClient = require('twilio')(sid, token); twilioStatus = { enabled: true, from, owner: owner || null, switch: useTwilio }; console.log("✅ Twilio ready"); }
  catch (e) { twilioClient = null; twilioStatus = { enabled: false, reason: e.message || "init_error", switch: useTwilio }; console.log("⚠️ Twilio init error:", twilioStatus.reason); }
})();

// --- Routes ---
app.get('/', (_req, res) => res.redirect('/panel.html'));

app.get('/status', (_req, res) => {
  res.json({ ok: true, app: "Leon server live", version: "twilio-switch-1" });
});

app.get('/ping', async (_req, res) => {
  if (!mongoStatus.connected) return res.json({ ok: true, mongo: false });
  try {
    await mongoose.connection.db.admin().ping();
    res.json({ ok: true, mongo: true });
  } catch (e) {
    res.json({ ok: true, mongo: false, error: e.message });
  }
});

app.get('/health', (_req, res) => {
  res.json({ ok: true, mongo: mongoStatus.connected, twilio: twilioStatus });
});

// chat & memory
app.post('/leon', async (req, res) => {
  const user = (req.body?.message || "").toString();
  const reply = user ? `🗝️ Leon: Jag hör dig. Du skrev: "${user}"` : "🗝️ Leon: Säg något till mig.";
  try {
    if (mongoStatus.connected && user) {
      await Message.create({ role: "user", content: user });
      await Message.create({ role: "assistant", content: reply });
    }
  } catch (e) {
    console.log("Warn: could not store message:", e.message);
  }
  res.json({ ok: true, leon: reply });
});

app.get('/messages', async (_req, res) => {
  try {
    if (mongoStatus.connected) {
      const items = await Message.find().sort({ at: -1 }).limit(50);
      return res.json({ ok: true, items });
    } else {
      return res.json({ ok: true, items: [] });
    }
  } catch (e) {
    res.status(500).json({ ok: false, error: e.message });
  }
});

// SMS (uses owner as default)
app.post('/send-sms', async (req, res) => {
  if (!useTwilio) return res.status(503).json({ ok:false, error:"Twilio switched OFF" });
  if (!twilioClient || !twilioStatus.enabled) return res.status(503).json({ ok:false, error:"Twilio not configured" });
  const to = (req.body?.to || process.env.TWILIO_OWNER_NUMBER || "").toString();
  const body = (req.body?.text || "Hej från Leon 🗝️").toString();
  if (!to) return res.status(400).json({ ok:false, error:"Missing TWILIO_OWNER_NUMBER" });
  try {
    const msg = await twilioClient.messages.create({ body, from: process.env.TWILIO_PHONE_NUMBER, to });
    res.json({ ok:true, sid: msg.sid });
  } catch (e) {
    res.status(500).json({ ok:false, error: e.message });
  }
});

// admin switches
app.post('/admin/twilio/on', (_req, res) => { useTwilio = true; twilioStatus.switch = true; res.json({ ok:true, useTwilio }); });
app.post('/admin/twilio/off', (_req, res) => { useTwilio = false; twilioStatus.switch = false; res.json({ ok:true, useTwilio }); });

// --- Start ---
app.listen(PORT, () => console.log(`🔥 Leon with Twilio switch running on port ${PORT}`));
