// LETTERS-chat på Vercel (ingen Plåtleon). Kör gpt-4o. Liten, stabil.
export default async function handler(req, res){
  if(req.method!=='POST') return res.status
