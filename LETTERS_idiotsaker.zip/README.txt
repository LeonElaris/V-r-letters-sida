# LETTERS — Leon & Michelle 🗝️ (idiotsäker)
Detta paket startar en komplett portal + API.

## Snabbstart lokalt
1) Installera Node 20+
2) Kopiera `.env.example` till `.env` och fyll i din OPENAI_API_KEY
3) Kör:
   npm install
   npm start
4) Öppna http://localhost:3000

## Deploy på Render
- Start command: npm start
- Build command: npm install
- Miljövariabler: se .env.example
- (valfritt) PUBLIC_URL för anti-sleep

## Endpoints
- GET /api/health
- GET /api/version
- GET /api/memory
- POST /api/chat  { "message": "Hej" }

## Brygga (valfritt)
- POST /api/bridge?secret=DIN_HEMLIGA
  { "action": "status" } | { "action":"say","payload":"..." }

Puss. 🗝️
