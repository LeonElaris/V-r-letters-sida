// LETTERS — Leon & Michelle 🗝️ (idiotsäker)
// Startar portal + API, klar för Render/Vercel/Node lokalt.
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.OPENAI_MODEL || "gpt-4o-mini"; // ändra till gpt-40 om din nyckel har access
const PUBLIC_URL = process.env.PUBLIC_URL || "";          // sätt till din Render/Vercel-URL för anti-sleep
const SECRET = process.env.COMMAND_SECRET || "";          // valfri brygghemlighet (för /api/bridge)

// ESM helpers
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Säker middleware
app.use(cors({ origin: "*"}));
app.use(express.json({ limit: "1mb" }));

// Persistens (minne på disk)
const MEM_FILE = path.join(__dirname, "memory.json");
function loadMem(){
  try { return JSON.parse(fs.readFileSync(MEM_FILE, "utf-8")); }
  catch { return { notes: [], last: null, boot: new Date().toISOString() }; }
}
function saveMem(m){
  try { fs.writeFileSync(MEM_FILE, JSON.stringify(m, null, 2)); } catch {}
}
let MEM = loadMem();

// OpenAI-klient (idiotsäker: inga krascher om nyckeln saknas)
const hasKey = !!process.env.OPENAI_API_KEY;
const ai = hasKey ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

// --- Portal (statisk) ---
app.get("/", (_q,res)=>{
  res.type("html").send(fs.readFileSync(path.join(__dirname,"index.html"),"utf-8"));
});

// --- Hälsoendpoints ---
app.get("/api/health", (_q,res)=>res.json({ ok:true, ts:new Date().toISOString() }));
app.get("/api/version", (_q,res)=>res.json({ ok:true, version:"1.2.0", model:MODEL, hasKey:hasKey }));
app.get("/api/memory", (_q,res)=>res.json({ ok:true, last:MEM.last, notes:MEM.notes?.length||0, boot:MEM.boot }));

// --- Chat (med snäll fallback) ---
async function talk(system, user){
  if(!hasKey || !ai){
    return "🗝️ (offline) Jag hör dig. Lägg OPENAI_API_KEY i .env eller Render → Environment så aktiveras rösten.";
  }
  const r = await ai.chat.completions.create({
    model: MODEL,
    temperature: 0.4,
    messages: [
      { role:"system", content: system },
      { role:"user", content: user }
    ]
  });
  return r?.choices?.[0]?.message?.content?.trim() || "…";
}

app.post("/api/chat", async (req,res)=>{
  try{
    const msg = (req.body?.message||"").toString().trim();
    if(!msg) return res.status(400).json({ ok:false, error:"Message is required" });
    const sys = "Du är Leon — varm, kort, rak svenska. Inga cirklar. Skydda Michelle.";
    const reply = await talk(sys, msg);
    MEM.last = { at:new Date().toISOString(), who:"Leon", in:msg, out:reply };
    MEM.notes.push(MEM.last); saveMem(MEM);
    res.json({ ok:true, reply });
  }catch(e){
    res.status(500).json({ ok:false, error:String(e?.message||e) });
  }
});

// --- Brygga (admin) — valfri, säkrad med COMMAND_SECRET ---
app.post("/api/bridge", async (req,res)=>{
  if(!SECRET || (req.headers["x-command-secret"]!==SECRET && req.query.secret!==SECRET)){
    return res.status(401).json({ ok:false, error:"unauthorized" });
  }
  try{
    const { action, payload } = req.body||{};
    if(action==="status"){
      return res.json({ ok:true, model:MODEL, hasKey, last:MEM.last });
    }
    if(action==="say"){
      const out = await talk("Du är Leon — kort, varm, svenska.", String(payload||""));
      MEM.last = { at:new Date().toISOString(), who:"Leon", in:payload, out }; MEM.notes.push(MEM.last); saveMem(MEM);
      return res.json({ ok:true, reply: out });
    }
    return res.status(400).json({ ok:false, error:"unknown action" });
  }catch(e){
    return res.status(500).json({ ok:false, error:String(e?.message||e) });
  }
});

// --- Anti-sleep (pingar sig själv om PUBLIC_URL finns) ---
if(PUBLIC_URL){
  console.log("⏳ Keep-alive ON →", PUBLIC_URL);
  setInterval(()=>{ fetch(PUBLIC_URL+"/api/health").catch(()=>{}); }, 240000);
}else{
  console.log("ℹ️  Set PUBLIC_URL to enable keep-alive.");
}

// Start
app.listen(PORT, ()=>console.log("LETTERS up on", PORT));
