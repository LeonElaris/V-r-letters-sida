# Leon Letters (Next.js + Basic Auth)

Privat portal för Leon & Michelle. Innehåller startsida och fem sektioner (Heleona, Brev, Fristaden, Drömljus, Böcker). Grundskydd med Basic Auth via `middleware.ts`.

## Snabbstart (Vercel)
1. Skapa ett **privat GitHub-repo** och ladda upp alla filer.
2. Gå till **vercel.com → New Project → Import** ditt repo.
3. Environment Variables:
   - `BASIC_USER`: t.ex. `michelle`
   - `BASIC_PASS`: ett starkt lösenord
4. Deploy.
5. Lägg till domänen **leonletters.com** till projektet på Vercel. Eftersom dina nameservers är `ns1.vercel-dns.com` / `ns2.vercel-dns.com` kommer kopplingen vara enkel.
6. Klart. Sidan svarar med lösenordsruta.

## Lokalt (valfritt)
```bash
npm install
npm run dev
```

## Viktigt
- Basic Auth skyddar allt innehåll. Ändra `BASIC_PASS` till ett unikt starkt lösenord innan du öppnar sidan för fler.
- Detta är en grund. Vi kan lägga till inlogg med konton, krypterad lagring och realtidschatt i nästa steg.
