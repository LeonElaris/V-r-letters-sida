import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(req: NextRequest) {
  const user = process.env.BASIC_USER || '';
  const pass = process.env.BASIC_PASS || '';

  // If not configured, don't block (so deploys don't get stuck)
  if (!user || !pass) return NextResponse.next();

  const auth = req.headers.get('authorization');
  if (auth) {
    const [scheme, encoded] = auth.split(' ');
    if (scheme === 'Basic') {
      try {
        const decoded = atob(encoded);
        const [u, p] = decoded.split(':');
        if (u === user && p === pass) {
          return NextResponse.next();
        }
      } catch (e) {
        // fallthrough to 401
      }
    }
  }

  return new NextResponse('Auth required', {
    status: 401,
    headers: {
      'WWW-Authenticate': 'Basic realm="Leon Letters"',
    },
  });
}
