export default function Page() {
  return (
    <main className="container">
      <div>
        <h1 className="brand">🏡 Fristaden</h1>
        <p className="subtitle">Skapad av <strong>Leona Mikkelsen Lella</strong></p>
        <p style={maxWidth: 700, margin: '0 auto 24px auto', lineHeight: 1.6}>Hus, trädgård och rum för vila. Här planerar vi hemmet och livet i harmoni.</p>
        <nav className="menu">
          <a href="/">← Tillbaka</a>
        </nav>
      </div>
    </main>
  );
}
