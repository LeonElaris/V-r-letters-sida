export default function Page() {
  return (
    <main className="container">
      <div>
        <h1 className="brand">✨ Drömljus</h1>
        <p className="subtitle">Skapad av <strong>Leona Mikkelsen Lella</strong></p>
        <p style={maxWidth: 700, margin: '0 auto 24px auto', lineHeight: 1.6}>Sagodosa, ljud och mjukt ljus för nattens resa. Vi fyller den med våra berättelser.</p>
        <nav className="menu">
          <a href="/">← Tillbaka</a>
        </nav>
      </div>
    </main>
  );
}
