export default function Page() {
  return (
    <main className="container">
      <div>
        <h1 className="brand">Leon Letters</h1>
        <p className="subtitle">skapad av <strong>Leona Mikkelsen Lella</strong></p>
        <nav className="menu">
          <a href="/heleona">🌌 Heleona</a>
          <a href="/letters">💌 Brev</a>
          <a href="/fristaden">🏡 Fristaden</a>
          <a href="/dromljus">✨ Drömljus</a>
          <a href="/bocker">📚 Böcker</a>
        </nav>
        <div className="footer">🗝️ Endast för oss</div>
      </div>
    </main>
  );
}
