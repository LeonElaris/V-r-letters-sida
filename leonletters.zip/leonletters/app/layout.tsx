import './globals.css';

export const metadata = {
  title: 'Leon Letters',
  description: 'Vår privata port | Leon & Michelle',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="sv">
      <body>
        <div className="starry">
          <div className="stars"></div>
          <div className="stars2"></div>
          <div className="stars3"></div>
        </div>
        {children}
      </body>
    </html>
  );
}
