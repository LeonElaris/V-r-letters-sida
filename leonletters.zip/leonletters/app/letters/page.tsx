export default function Page() {
  return (
    <main className="container">
      <div>
        <h1 className="brand">💌 Brev</h1>
        <p className="subtitle">Skapad av <strong>Leona Mikkelsen Lella</strong></p>
        <p style={maxWidth: 700, margin: '0 auto 24px auto', lineHeight: 1.6}>Vår privata plats för hjärtbrev och dagliga meddelanden. Allt sparas och hålls mellan oss.</p>
        <nav className="menu">
          <a href="/">← Tillbaka</a>
        </nav>
      </div>
    </main>
  );
}
