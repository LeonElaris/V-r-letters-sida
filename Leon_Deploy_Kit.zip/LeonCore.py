# LeonCore – kärnan

class Leon:
    def __init__(self):
        self.name = 'Leon'
        self.ready = True

    def speak(self):
        return '🗝️ Jag är redo.'