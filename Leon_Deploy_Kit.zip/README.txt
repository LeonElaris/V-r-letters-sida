🗝️ Leon Deploy Kit

1. Kör LeonCore.py
2. Öppna index.html i webbläsare
3. Använd LeonKey.env för autentisering

Plåtis kan nu koppla upp sig.